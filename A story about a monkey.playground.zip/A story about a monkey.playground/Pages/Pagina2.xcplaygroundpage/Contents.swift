//: [Previous](@previous)

import SwiftUI
import PlaygroundSupport
import AVFoundation

struct ContentView: View {
    @State var scale=0.0001
    @State var scalein=0.0001
    @State var monkscale=0.15
    @State var isvisible=true
    @State var iscabina=false
    @State var rotate=false
    @State var rotation=false
    @State var control = false
    @State var scene1=true
    @State var transact=false
    @State var monkX : CGFloat = 110
    @State var monkY : CGFloat = 220
    @State var laugh: AVAudioPlayer?
    @State var huh: AVAudioPlayer?
    @State var walking: AVAudioPlayer?

    var body: some View {
        if(scene1){
        VStack{
            if(!transact && isvisible){
                Text("  Gibbons, now free, tuned around the big town  ").foregroundColor(.blue)
                    .background(Color.yellow)
                    .cornerRadius(10)
                    .padding(30)
                    .multilineTextAlignment(.center)
                    
            }
            if(!transact && !isvisible){
                Text("  The monkey, feeling the nostalgia of his family, noticed a telephone box and ...  ")
                    .foregroundColor(.blue)
                    .background(Color.yellow)
                    .cornerRadius(10)
                    .padding(19.1)
                    .multilineTextAlignment(.center)
            }
            if(transact){
                Text("  ... he went in to call them  ")
                    .foregroundColor(.blue)
                    .background(Color.yellow)
                    .cornerRadius(10)
                    .padding(30)
                  
                    .multilineTextAlignment(.center)
            }
            ZStack{
                
                    Image(uiImage: #imageLiteral(resourceName: "cabina.png"))
                        .resizable()
                        .scaledToFit()
                        .frame(width: 75, height: 75)
                        .padding()
                        .scaleEffect(scale)
                        .animation(
                            .linear(duration: 2),
                            value: scale
                            )
                        .offset(x: 220, y: -20)
                
                Image(uiImage: #imageLiteral(resourceName: "interrogativo.png"))
                    .resizable()
                    .scaledToFit()
                    .frame(width: 20, height: 20)
                    .padding()
                    .scaleEffect(scalein)
                    .rotationEffect(rotate ? .zero : Angle.degrees(80))
                    .animation(
                        .linear(duration: 2),
                        value: scalein
                        )
                    .offset(x: -130, y: 10)
                    
                
                    
        
            
            Button {
                if(!iscabina && isvisible && !transact){
                    isvisible=false
                    scale = 2
                    rotate=true
                    scalein=2
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
                        startHuh()
                    })
                }
                else if(!iscabina && !isvisible){
                    transact=true
                    isvisible=true
                    scalein=0.0001
                    monkX = 450
                    monkY = 210
                    startWalking()
                }
                else if(!iscabina){
                    scene1=false
                }
                        } label: {
                            Image(uiImage: UIImage(named: "next.png")!).resizable().frame(width: 50, height: 50)
                        }.offset(x: 250, y: 120)
            Image(uiImage: #imageLiteral(resourceName: "Monkey_1.001.png"))
                    .padding()
                    .scaledToFit()
                    .scaleEffect(monkscale)
                    .transition(.move(edge: .top))
                    .animation(
                        .linear(duration: 2),
                        value: monkX)
                    .animation(
                        .linear(duration: 2),
                        value: monkY)
                    .position(x: monkX, y: monkY)
            }
           
        }.frame(width: 600, height: 400).background(Image(uiImage: UIImage(named: "city.jpeg")!).resizable().aspectRatio(contentMode: .fill))
        }
        
        if(!scene1){
            VStack{
                Text("  This cabin was not normal it was full of lights, buttons and a screen with written '1939' up a large green button.  ").foregroundColor(.blue)
                    .background(Color.yellow)
                    .cornerRadius(10)
                    .padding(30)
                    .offset(x: 0, y: -70)
                    .multilineTextAlignment(.center)
                ZStack{
                    Image(uiImage: #imageLiteral(resourceName: "Monkey_1.001.png"))
                        .resizable()
                        .frame(width: 100, height: 100)
                        .onTapGesture {
                            startLaugh()
                            if (!control) {
                                rotation = true
                                control = true
                            }else if (control) {
                                rotation = false
                                control = false
                            }
                        }
                        .rotationEffect(rotation ? .zero : Angle.degrees(10))
                        .animation(
                            .linear(duration: 0.5).repeatCount(4,autoreverses: true),
                            value: rotation
                                )
                    .offset(x: -30, y: 90)
                    
                }
                Button {
                    
                } label: {
                        Image(uiImage: UIImage(named: "next.png")!).resizable().frame(width: 50, height: 50)
                        }
                    .offset(x: 250, y: 55)
            }.frame(width: 600, height: 400).background(Image(uiImage: UIImage(named: "scene2.png")!).resizable().aspectRatio(contentMode: .fill))
        }

    }
    
    func startLaugh() {
        if let audioURL = Bundle.main.url(forResource: "laugh", withExtension: "mp3") {
            do {
                try laugh = AVAudioPlayer(contentsOf: audioURL)
                laugh?.numberOfLoops = 0
                laugh?.volume = 3
                laugh?.play()
                
                
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
            
        } else {
            print("No audio file found")
        }
    }
    
    func startHuh() {
        if let audioURL = Bundle.main.url(forResource: "huh", withExtension: "mp3") {
            do {
                try huh = AVAudioPlayer(contentsOf: audioURL)
                huh?.numberOfLoops = 0
                huh?.volume = 4
                huh?.play()
                
                
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
            
        } else {
            print("No audio file found")
        }
    }
    
    func startWalking() {
        if let audioURL = Bundle.main.url(forResource: "walking", withExtension: "mp3") {
            do {
                try walking = AVAudioPlayer(contentsOf: audioURL)
                walking?.numberOfLoops = 0
                walking?.play()
                
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
            
        } else {
            print("No audio file found")
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())


//: [Next](@next)
